package week5.day2.assignment2;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import io.github.bonigarcia.wdm.WebDriverManager;
import io.github.sukgu.Shadow;

public class BaseClass {

	public ChromeDriver driver;
	public String excelFileName;
	public String excelSheetName;

	@BeforeMethod
	@Parameters({ "url", "username", "password" })
	public void preCondition(
			@Optional("https://dev123621.service-now.com/login.do?user_name=admin&sys_action=sysverb_login&user_password=VQ%3Dd2Ggo3pL%2F:") String url,
			String uName, String pWord) throws InterruptedException {

		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();

		// Load ServiceNow application URL
		driver.get(url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

		// Enter username
		driver.findElement(By.xpath("//input[@id='user_name']")).sendKeys(uName);

		// Enter password
		driver.findElement(By.xpath("//input[@id='user_password']")).sendKeys(pWord);

		// Click Login
		driver.findElement(By.xpath("//button[@id='sysverb_login']")).click();
		Thread.sleep(15000);

		Shadow shadow = new Shadow(driver);

		// Search �incident � Filter Navigator"
		WebElement filter = shadow.findElementByXPath("//div[@class='starting-header-zone']//div[@id='all']");
		filter.click();
		Thread.sleep(2000);
		shadow.findElementByXPath("//label[@for='filter']/following-sibling::input[@id='filter']")
				.sendKeys("Incidents");
		filter.click();
		shadow.findElementByXPath("//span[@class='item-icon']//mark[text()='Incidents']").click();

		// Click �All�
		WebElement frame = shadow.findElementByXPath("//iframe[@id='gsft_main']");
		driver.switchTo().frame(frame);
		driver.findElement(By.xpath("//span[@id='incident_breadcrumb']//*[text()='All']")).click();

		// Click New button
		shadow.findElementByXPath("//span[@id='incident_choice_actions']/following-sibling::button[@type='submit']")
				.click();
		driver.switchTo().defaultContent();
	}

	@AfterMethod
	public void postCondition() {
		driver.close();
	}

	@DataProvider
	public String[][] getTestData() throws IOException {
		return ReadExcelData.fetchExcelData(excelFileName, excelSheetName);
	}

}
