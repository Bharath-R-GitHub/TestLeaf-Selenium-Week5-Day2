package week5.day2.assignment1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class EditLead extends BaseClass {

	@BeforeTest()
	public void setFileDetails() {
		excelFileName = "EditLead";
		excelSheetName = "EditLead";
	}

	@Test(dataProvider = "getTestData")
	public void editLead(String cName, String fName, String lName, String locFName, String dept, String desc,
			String email, String state, String impNote) {

		// Click on Create Lead
		driver.findElement(By.linkText("Create Lead")).click();

		// Enter CompanyName Field Using id Locator
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cName);

		// Enter FirstName Field Using id Locator
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fName);

		// Enter LastName Field Using id Locator
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lName);

		// Enter FirstName(Local) Field Using id Locator
		driver.findElement(By.id("createLeadForm_firstNameLocal")).sendKeys(locFName);

		// Enter Department Field Using any Locator of Your Choice
		driver.findElement(By.id("createLeadForm_departmentName")).sendKeys(dept);

		// Enter Description Field Using any Locator of your choice
		driver.findElement(By.id("createLeadForm_description")).sendKeys(desc);

		// Enter your email in the E-mail address Field using the locator of your
		// choice
		driver.findElement(By.id("createLeadForm_primaryEmail")).sendKeys(email);

		// Select State/Province as NewYork Using Visible Text
		WebElement ddElement = driver.findElement(By.id("createLeadForm_generalStateProvinceGeoId"));
		Select dd = new Select(ddElement);
		dd.selectByVisibleText(state);

		// Click on Create Button
		driver.findElement(By.name("submitButton")).click();

		// Click on edit button
		driver.findElement(By.linkText("Edit")).click();

		// Clear the Description Field using .clear()
		driver.findElement(By.id("updateLeadForm_description")).clear();

		// Fill ImportantNote Field with Any text
		driver.findElement(By.id("updateLeadForm_importantNote")).sendKeys(impNote);

		// Click on update button
		driver.findElement(By.className("smallSubmit")).click();

		// Get the Title of Resulting Page
		String resultingPage = driver.getTitle();
		System.out.println(resultingPage);
	}
}
