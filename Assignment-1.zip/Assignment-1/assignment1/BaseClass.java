package week5.day2.assignment1;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseClass {

	public ChromeDriver driver;
	public String excelFileName;
	public String excelSheetName;

	@BeforeMethod
	@Parameters({ "url", "username", "password" })
	public void preCondition(String url, String uName, String pWord) {

		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();

		// Launch URL "http://leaftaps.com/opentaps/control/login"
		driver.get(url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

		// Enter UserName and Password Using Id Locator
		driver.findElement(By.id("username")).sendKeys(uName);
		driver.findElement(By.id("password")).sendKeys(pWord);

		// Click on Login Button using Class Locator
		driver.findElement(By.className("decorativeSubmit")).click();

		// Click on CRM/SFA Link
		driver.findElement(By.linkText("CRM/SFA")).click();

		// Click on Lead
		driver.findElement(By.linkText("Leads")).click();
	}

	@AfterMethod
	public void postCondition() {
		driver.close();
	}

	@DataProvider
	public String[][] getTestData() throws IOException {
		return ReadExcelData.fetchExcelData(excelFileName, excelSheetName);
	}

}
