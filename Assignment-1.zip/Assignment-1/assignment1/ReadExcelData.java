package week5.day2.assignment1;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcelData {
	public static String[][] fetchExcelData(String fileName, String sheetName) throws IOException {
		XSSFWorkbook wb = new XSSFWorkbook("./Week5Assignment1TestData/" + fileName + ".xlsx");
		XSSFSheet ws = wb.getSheet(sheetName);
		int rowCount = ws.getLastRowNum();
		int columnCount = ws.getRow(1).getLastCellNum();

		String[][] data = new String[rowCount][columnCount];

		for (int i = 1; i <= rowCount; i++) {
			for (int j = 0; j < columnCount; j++) {
				String cellValue = ws.getRow(i).getCell(j).getStringCellValue();
				data[i - 1][j] = cellValue;
			}
		}

		wb.close();

		return data;
	}
}
