package week5.day2.assignment1;

import org.openqa.selenium.By;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class DeleteLead extends BaseClass {

	@BeforeTest()
	public void setFileDetails() {
		excelFileName = "DeleteLead";
		excelSheetName = "DeleteLead";
	}

	@Test(dataProvider = "getTestData")
	public void deleteLead(String phoneNum) throws InterruptedException {

		// Click Find leads
		driver.findElement(By.xpath("//a[text()='Find Leads']")).click();

		// Click on Phone
		driver.findElement(By.xpath("//span[text()='Phone']")).click();

		// Enter phone number
		driver.findElement(By.name("phoneNumber")).sendKeys(phoneNum);

		// Click find leads button
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		Thread.sleep(2000);

		// Capture lead ID of First Resulting lead
		String firstLeadID = driver.findElement(By.xpath("//div[contains(@class,'x-grid3-col-partyId')]/a[1]"))
				.getText();
		System.out.println("The First Lead ID is " + firstLeadID);
		Thread.sleep(2000);

		// Click First Resulting lead
		driver.findElement(By.xpath("//div[contains(@class,'x-grid3-col-partyId')]/a[1]")).click();

		// Click Delete
		driver.findElement(By.xpath("//a[text()='Delete']")).click();

		// Click Find leads
		driver.findElement(By.xpath("//a[text()='Find Leads']")).click();
		Thread.sleep(2000);

		// 15 Enter captured lead ID
		driver.findElement(By.xpath("//div[@class='x-form-element']/input[@name='id']")).sendKeys(firstLeadID);

		// Click find leads button
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		Thread.sleep(2000);

		// Verify message "No records to display" in the Lead List. This message
		// confirms the successful deletion
		String verify = driver.findElement(By.xpath("//div[@class='x-paging-info']")).getText();
		if (verify.equals("No records to display")) {
			System.out.println("I confirmed that the Lead ID " + firstLeadID + " has been Deleted Successfully");
		} else {
			System.out.println("The Lead ID " + firstLeadID + " has not Deleted yet");
		}
	}
}
