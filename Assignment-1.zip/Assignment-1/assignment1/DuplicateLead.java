package week5.day2.assignment1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class DuplicateLead extends BaseClass {

	@BeforeTest()
	public void setFileDetails() {
		excelFileName = "DuplicateLead";
		excelSheetName = "DuplicateLead";
	}

	@Test(dataProvider = "getTestData")
	public void duplicateLead(String cName, String fName, String lName, String locFName, String dept, String desc,
			String email, String state, String newCompName, String newFName) {

		// Click on Create Lead
		driver.findElement(By.linkText("Create Lead")).click();

		// Enter CompanyName Field Using id Locator
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cName);

		// Enter FirstName Field Using id Locator
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fName);

		// Enter LastName Field Using id Locator
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lName);

		// Enter FirstName(Local) Field Using id Locator
		driver.findElement(By.id("createLeadForm_firstNameLocal")).sendKeys(locFName);

		// Enter Department Field Using any Locator of Your Choice
		driver.findElement(By.id("createLeadForm_departmentName")).sendKeys(dept);

		// Enter Description Field Using any Locator of your choice
		driver.findElement(By.id("createLeadForm_description")).sendKeys(desc);

		// Enter your email in the E-mail address Field using the locator of your
		// choice
		driver.findElement(By.id("createLeadForm_primaryEmail")).sendKeys(email);

		// Select State/Province as NewYork Using Visible Text
		WebElement ddElement = driver.findElement(By.id("createLeadForm_generalStateProvinceGeoId"));
		Select dd = new Select(ddElement);
		dd.selectByVisibleText(state);

		// Click on Create Button
		driver.findElement(By.name("submitButton")).click();

		// Get the Title of Resulting Page
		String resultingPage = driver.getTitle();
		System.out.println(resultingPage);

		// Click on Duplicate button
		driver.findElement(By.linkText("Duplicate Lead")).click();

		// Clear the CompanyName Field And Enter new CompanyName
		driver.findElement(By.id("createLeadForm_companyName")).clear();
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(newCompName);

		// Clear the FirstName Field And Enter new FirstName
		driver.findElement(By.id("createLeadForm_firstName")).clear();
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(newFName);

		// Click on Create Lead Button
		driver.findElement(By.className("smallSubmit")).click();

		// Get the Title of Resulting Page
		String finalPage = driver.getTitle();
		System.out.println(finalPage);
	}
}
